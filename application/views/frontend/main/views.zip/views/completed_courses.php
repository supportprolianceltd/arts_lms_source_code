<?php
echo <<<HTML
  <section class="page-section">
    <div class="main-section">
      <div class="section-header">
        <h2>Completed Courses</h2>
      </div>

      <div class="oova-clous-sec">
        $td_top_courses
      </div>

   

      <div class="page-pegination">
        <button><i class="icon-arrow-left"></i></button> 
        <span>Page 1</span> 
        <button><i class="icon-arrow-right"></i></button> 
    </div>
 
      

    </div><!-- main-section -->
HTML;
?>
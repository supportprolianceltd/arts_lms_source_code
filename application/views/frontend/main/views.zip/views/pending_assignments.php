<?php
echo <<<HTML
  <section class="page-section">
    <div class="main-section">
      <div class="section-header">
        <h2>Pending Assessments</h2>
      </div>

      <div class="oova-clous-sec">



        
        <div class="CCL-Box">
          <div class="CCL-Box-Top">
            <div class="CCL-Box-Top-1">
              <p>NCFE CACHE Level 2 Award in Awareness of dementia 600/3095/1</p>
            </div>
            <div class="CCL-Box-Top-2">
              <h6>Progress - 10%</h6>
              <div class="CCL-Box-Top-2-Btns">
                <a href="#" class="start-learning-btn"><i class="ti-pencil"></i> Continue Test</a>
              </div>
            </div>
          </div>
          <div class="CCL-Box-Sub">
            <div class="CCL-Box-Sub-10">
              <h2><span>Score:</span> 0/100</h2>
              <h3><span>Questions:</span> 20</h3>
              <h3><span>Duration:</span> 2hrs 10mins 40sec</h3>
          </div>
            <div class="CCL-Box-Sub-2">
              <span class="pending-span-badge">Pending</span>
              <p><i class="icon-calender"></i>2/23/2025</p>
            </div>
          </div>
        </div>


           
        <div class="CCL-Box">
          <div class="CCL-Box-Top">
            <div class="CCL-Box-Top-1">
              <p>NCFE CACHE Level 2 Award in Awareness of dementia 600/3095/1</p>
            </div>
            <div class="CCL-Box-Top-2">
              <h6>Progress - 10%</h6>
              <div class="CCL-Box-Top-2-Btns">
                <a href="#" class="start-learning-btn"><i class="ti-pencil"></i> Continue Test</a>
              </div>
            </div>
          </div>
          <div class="CCL-Box-Sub">
            <div class="CCL-Box-Sub-10">
              <h2><span>Score:</span> 0/100</h2>
              <h3><span>Questions:</span> 20</h3>
              <h3><span>Duration:</span> 2hrs 10mins 40sec</h3>
          </div>
            <div class="CCL-Box-Sub-2">
              <span class="pending-span-badge">Pending</span>
              <p><i class="icon-calender"></i>2/23/2025</p>
            </div>
          </div>
        </div>








      </div>

   

      <div class="page-pegination">
        <button><i class="icon-arrow-left"></i></button> 
        <span>Page 1</span> 
        <button><i class="icon-arrow-right"></i></button> 
    </div>
 
      

    </div><!-- main-section -->
HTML;
?>
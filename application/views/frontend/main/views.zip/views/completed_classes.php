<?php
echo <<<HTML
  <section class="page-section">
    <div class="main-section">
      <div class="section-header">
        <h2>Completed Classes</h2>
      </div>

      <div class="oova-clous-sec">

        <div class="classs-ses-Grid">


          <div class="classs-ses-Card">
            <h2>Booked class <span class="completed-span-badge">Completed</span></h2>
            <h3>Level 1</h3>
            <p>
              <span><i class="icon-calender"></i> 24/2/2025</span>
              <span><i class="ti-timer"></i> Duration: <b>6 months</b></span>
          </p>
          
          <div class="classs-ses-Card-btn">
            <a href="class-schedule.html"><i class="ti-agenda"></i> View Schedule</a>
          </div>
        </div>



      </div>

   

      <div class="page-pegination">
        <button><i class="icon-arrow-left"></i></button> 
        <span>Page 1</span> 
        <button><i class="icon-arrow-right"></i></button> 
    </div>
 
      

    </div><!-- main-section -->
HTML;
?>
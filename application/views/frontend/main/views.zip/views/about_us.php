<?php
echo <<<HTML
<header class="header-section gen-header about-us-header">
    <div class="main-container">
      <div class="hero-sec">
        <div class="hero-banner"></div>
        <div class="hero-dlt">
          <div>
          <h1 class="big-text">About us</h1>
          <p>We are people oriented online training development platform. It is our desire to contribute towards people and business growth through effective learning.</p>
          
          </div>
        </div>

        <div class="hero-banner"></div>

      </div>

    </div>


    <div class="header-wave-Div">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#fff" fill-opacity="1" d="M0,64L120,80C240,96,480,128,720,133.3C960,139,1200,117,1320,106.7L1440,96L1440,320L1320,320C1200,320,960,320,720,320C480,320,240,320,120,320L0,320Z"></path></svg>
    </div>

  </header>
  


  <section class="abt-testi-sec">
    <div class="main-container">
      <div class="abt-sec">

        <div class="abt-Dlt mmm-Bt-Pappg">
          <div>
            <h2 class="big-text">Upskilling talent for the careers of the future</h2>
            <p>We are people oriented online training development platform. It is our desire to contribute towards people and business growth through effective learning.</p>
          </div>
        </div>

        <div class="abt-Img" data-aos="fade-up" data-aos-duration="1000" >
          <img src="$system_assets_base_url/img/about-page-AAABT.png" />
        </div>

      </div>


    </div>
  </section>




  <section class="main-TTT-sec">
    <div class="main-container">
      <div class="reviews-sec rrre-Sec">
        <div class="reviews-header">
          <h3 class="big-text">Our mission, vission and value</h3>
        </div>
  
        <div class="reviews-main rrre-Grid">
  
              <div class="reviews-card">
                <h2>Mission</h2>
                <p>To bridge knowledge gaps and support people development through effective online training solutions</p>
        </div>

        <div class="reviews-card">
          <h2>Vision</h2>
          <p>To be a leading and recognized people oriented and development online training provider around the world</p>
  </div>

  <div class="reviews-card">
    <h2>Value</h2>
    <p>We believe that both our people and customers shall experience personal and professional <strong>GROWTH</strong> through our learning solutions</p>
</div>

  
        </div>


        <div class="triust-sec">
          <p>Trusted by</p>
          <div class="triust-Img">
            <img src="$system_assets_base_url/img/PartImg/1.png" />
            <img src="$system_assets_base_url/img/PartImg/2.png" />
            <img src="$system_assets_base_url/img/PartImg/3.png" />
          </div>
        </div>


      </div>
      </section>


  
      <section class="geti-sec">
        <div class="main-container">
          <div class="geti-main">
            <div class="geti-Box">
            <h2 class="large-text">Improving lives through learning</h2>
            <a href="$system_base_url/home/book_class">Book a class now</a>
          </div>
          </div>
        </div>
      </section>
HTML;
?>
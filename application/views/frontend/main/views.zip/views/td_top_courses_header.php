<?php
$top_courses_sub_category_card_td.=<<<HTML
    <a href="$top_course_url" data-image="$top_course_img_url">{$top_course['title']}</a>
HTML;
?>
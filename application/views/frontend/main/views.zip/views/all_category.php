<?php
echo <<<HTML
  <header class="header-section gen-header teaching-and-learning-header">
    <div class="main-container">
      <div class="hero-sec">
        <div class="hero-banner"></div>
        <div class="hero-dlt">
          <div style='min-width:50% !important;'>
          <h1 class="big-text">$booking_text</h1>
          <p class='d-none'>$booking_text</p>
          <form action='$system_base_url/home/courses' id='search_form'>
            <div class="hero-search-sec">
              <input type="text" name='search_string' placeholder="Search for courses here.." />
              <button onclick='search_form.submit()'><i class="ti-search"></i></button>
            </div>
        </form>
          
          </div>
        </div>

        <div class="hero-banner"></div>

      </div>

    </div>


    <div class="header-wave-Div">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#fff" fill-opacity="1" d="M0,64L120,80C240,96,480,128,720,133.3C960,139,1200,117,1320,106.7L1440,96L1440,320L1320,320C1200,320,960,320,720,320C480,320,240,320,120,320L0,320Z"></path></svg>
    </div>

  </header>
  


  <section class="couseeee-Top-sec">
    <div class="main-container">
      <div class="GGF-Coursee">
        <h2 class='d-none'>Categories</h2>
      </div>
      <div class="Gland-Sec $popular_category_cards_disp">
        $top_courses_category_card_td
      </div>

      
    </div>
  </section>


  <section class="abt-testi-sec">
    <div class="main-container">
      <div class="abt-sec">

        <div class="abt-Dlt">
          <div>
            <h6>{$category['name']}</h6>
            <h2 class="big-text">A.R.T.S Training</h2>
            <p>Our Training offers expert-led courses focused on effective learning strategies, ensuring you receive quality education and care.</p>
          </div>
        </div>

        <div class="abt-Img" data-aos="fade-up" data-aos-duration="1000" >
          <img src="$system_assets_base_url/img/teaching-and-learning-ABT.png" />
        </div>

      </div>

      


    </div>
  </section>
HTML;
?>
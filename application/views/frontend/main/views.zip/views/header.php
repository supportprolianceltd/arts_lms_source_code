 <?php
 echo <<<HTML
<body>
<link rel="stylesheet" href="$system_assets_base_url/css/main.css"/>
<link rel="stylesheet" href="$system_assets_base_url/css/style.css"/>
<nav class="custom-navbar">
    <div class="site-container nav-content">
      <a href="$system_base_url/home" class="nav-brand">
        <img src="$system_frontend_base_url/{$system_frontend_settings['light_logo']}" class="logo-1" />
        <img src="$system_frontend_base_url/{$system_frontend_settings['dark_logo']}" class="logo-2" />
      </a>
      <div class="nav-icons">
        <div class="mobil-topss">
        <button>
          <i class="ti-close"></i>
        </button>
      </div>
        <ul>
          $top_courses_category_card_td

          <li><a href="$system_base_url/home/book_class">Book a class</a></li>

          <li class="Li-show-on-mobile"><a href="$system_base_url/home/about_us">About us</a></li>

          <li class="Li-show-on-mobile"><a href="$system_base_url/home/contact_us">Contact us</a></li>

        </ul>
        <ul class="right-UllL">
          
   
        <span class='$__hide_elem_class_if_logged_in' id="Span-oamnw">
     
            <li><button class="search-button"><i class="ti-search"></i></button></li>
            <li><a href="$system_base_url/home/login" class="login-btn">Log in</a></li>
            <li><a href="$system_base_url/home/sign_up" class="signup-btn">Sign up</a></li>
       
        </span>
        <span class='$__hide_elem_class_if_admin' id="Span-oamnw">
  
            <li><a href="$system_base_url/home/my_courses" class="signup-btn">Dashboard</a></li>
    
        </span>
        <span class='$__show_elem_class_if_admin' id="Span-oamnw">
   
            <li><a href="$system_base_url/admin/" class="signup-btn">Admin</a></li>
        
        </span>
        
          <li><a href="https://cmvp.net/verification/4b832a6e-bba1-4e15-b7d5-6da5657512f0/ARTS/" class="verify-btn">Verify Certificate</a></li>
          
            </ul>
      </div>

    <div class="mobille-Gland">
      <button class="search-button"><i class="ti-search"></i></button>
      <div class="mobile-toggle-nav">
        <span></span>
      </div>
    </div>
    </div>

    <div class="search-dropdown-sec">
      <div class="site-container">
        <h3>What do you want to learn today? <button><i class="ti-close"></i></button></h3>
        <form action='$system_base_url/home/courses' id='search_form'>
          <div class="search-box">
            <input type="text" name="search_string" placeholder="What do you want to learn today?" />
            <button onclick='search_form.submit()'><i class="ti-search"></i></button>
          </div>
        </form>
      </div>
    </div>
  </nav>
HTML;
?>


<style>
  @media screen and (min-width:1200px){
    #Span-oamnw{
        position:relative;
        display:inline-flex;
        align-items:center;
        gap:10px;
    }

    }
    
    
</style>

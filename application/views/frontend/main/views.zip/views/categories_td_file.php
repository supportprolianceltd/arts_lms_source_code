<?php
    $categories_td.="<button class='$active_btn'>{$categories_list['name']}</button>";
?>
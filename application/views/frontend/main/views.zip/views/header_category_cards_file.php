<?php
//$top_courses_sub_category_card_td=null;
//$categories_td_file='header_sub_category_cards_file';
//$categories_lists=$this->crud_model->get_sub_categories($top_courses_category_card['id']);
//require(__DIR__.'/../categories_list.php');

$td_top_courses_file='td_top_courses_header';
$top_courses=$top_courses_card;
$top_courses_sub_category_card_td=null;
require_once(__DIR__.'/../course_list_grid.php');
$td_top_courses_file=null;

$top_courses_category_card_td.=<<<HTML
<li class="Li-hide-on-mobile">
          <span>{$top_courses_category_card['name']}<i class="ti-angle-down"></i></span>
          
          <div class="nav-drop-down-box">
            <div class="nav-drop-down-left">
              <img id="course-image" src="$top_courses_category_card_thumbnail" />
            </div>
            <div class="nav-drop-down-right">
              <div class="drop-top-navi d-none">
                <button class="active-btn">Courses</button>
                <button>Qualifications</button>
              </div>

              <div class="dropdown-navid mandatory-courses-drop">
              <div class="dropdown-navid-top">
                <p>Courses</p>
                <a href="$system_base_url/home/category/$top_courses_category_card_name_slug/{$top_courses_category_card['id']}">All courses</a>
              </div>

              <div class="dropdown-navid-main">
                <div class="dropdown-navid-main">
                  $top_courses_sub_category_card_td
                </div>
              </div>

            </div>
        
        </li>
        <li class="Li-show-on-mobile"><a href="$system_base_url/home/category/$top_courses_category_card_name_slug/{$top_courses_category_card['id']}">{$top_courses_category_card['name']}</a></li>
HTML;
?>
<?php
echo <<<HTML
  <section class="page-section">
    <div class="main-section">
      <div class="section-header">
        <h2>Certificates</h2>
      </div>

      <div class="oova-clous-sec">

        <div class="classs-ses-Grid">


          <div class="classs-ses-Card">
            <h2>Certificate Title <span class="ongoing-span-badge">Ready</span></h2>
            <h6>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</h6>
            <p>
              <span><i class="icon-calender"></i> 24/2/2025</span>
          </p>
          
          <div class="classs-ses-Card-btn">
            <a href="#"><i class="icon-badge"></i> Download Certificate</a>
              <span><a href="https://www.cmvp.net/" target="_blank">www.cmvp.net</a></span>
          </div>
        </div>



     

    

        

      </div>

   

      <div class="page-pegination">
        <button><i class="icon-arrow-left"></i></button> 
        <span>Page 1</span> 
        <button><i class="icon-arrow-right"></i></button> 
    </div>
 
      

    </div><!-- main-section -->
HTML;
?>
<?php
echo <<<HTML
 <div class="Advert-popop-sec" id="advertPopup" style='$banner_disp'>
    <button class="close-popup" id="closeAdvertBtn"><i class="ti-close"></i></button>
    <a href="{$system_settings['footer_link']}" class="Advert-popop-banner">
      <img src="$system_frontend_base_url/{$system_frontend_settings_banner_image['home_1']}" />
    </a>
  </div>

  <header class="header-section">
    <div class="main-container">
      <div class="hero-sec">
        <div class="hero-banner">
        
        </div>
        <div class="hero-dlt">
          <div>
          <h1 class="big-text">Accredited Recognized Training Solutions</h1>
          <p>We offer bespoke mandatory, induction and accredited training for all care providers and other professionals.</p>
          <form action='$system_base_url/home/courses' id='search_form'>
            <div class="hero-search-sec">
                <input type="text" name='search_string' placeholder="What do you want to learn today?" />
                <button onclick='search_form.submit()'><i class="ti-search"></i></button>
            </div>
          </form>
          
          </div>
        </div>

        <div class="hero-banner"> </div>

      </div>
      <div class="hero-footer">
        <p>We are recognized by</p>
        <img src="$system_assets_base_url/img/accred-parts.png" />
      </div>
    </div>

   

  </header>





  <section class="main-TTT-sec $popular_categories_disp">
    <div class="main-container">
      <div class="courses-sec">
        <div class="courses-header">
          <h3>Mandatory Courses</h3>

          <div class="courses-header-btns d-none">
            $top_courses_categories_button
          </div>
          
        </div>
        $category_top_courses_td
  
      </div>
      
      
      
      
       <div class="courses-sec">
        <div class="courses-header">
          <h3>Mandatory Courses</h3>

          <div class="courses-header-btns d-none">
            $top_courses_categories_button
          </div>
          
        </div>
        $category_top_courses_td
  
      </div>






      <div class="triust-sec">
        <p>Trusted by</p>
        <div class="triust-Img">
          <img src="$system_assets_base_url/img/PartImg/1.png" />
          <img src="$system_assets_base_url/img/PartImg/2.png" />
          <img src="$system_assets_base_url/img/PartImg/3.png" />
        </div>
      </div>
    </div>
  </section>



  <section class="abt-testi-sec">
    <div class="main-container">
      <div class="abt-sec">

        <div class="abt-Dlt">
          <div>
            <h6>A.R.T.S Trainging Services</h6>
            <h2 class="big-text">Amazing learning experience with A.R.T.S</h2>
            <p>Engage your workforce with our mandatory and induction courses. We provide all the learning your workforce needs to be compliant with CQC and Skills for Care requirements.</p>
            <a href="$system_base_url/home/about_us">Learn more <i class="ti-angle-right"></i></a>
          </div>
        </div>

        <div class="abt-Img" data-aos="fade-up" data-aos-duration="1000" >
          <img src="$system_assets_base_url/img/HH-Abt-img.png" />
        </div>

      </div>

      <div class="yahn-Sec">
        <div class="yahn-Card" data-aos="fade-up" data-aos-duration="500">
          <div class="yahn-Card-top">
          <div class="yahn-Card-1">
            <img src="$system_assets_base_url/img/Tt-Card-img/1.png" />
          </div>
          <div class="yahn-Card-2">
            <h4>Virtual learning</h4>
          </div>
        </div>
        <p>The UK’s most respected and recognised courses delivered in an interactive, live online classroom.</p>
        </div>


        <div class="yahn-Card" data-aos="fade-up" data-aos-duration="1000">
          <div class="yahn-Card-top">
          <div class="yahn-Card-1">
            <img src="$system_assets_base_url/img/Tt-Card-img/2.png" />
          </div>
          <div class="yahn-Card-2">
            <h4>Classroom learning</h4>
            </div>
          </div>
          <p>Attend a training course in a specialist, quiet and focused environment.</p>
        </div>


        <div class="yahn-Card" data-aos="fade-up" data-aos-duration="1500">
          <div class="yahn-Card-top">
          <div class="yahn-Card-1">
            <img src="$system_assets_base_url/img/Tt-Card-img/3.png" />
          </div>
          <div class="yahn-Card-2">
            <h4>E-Learning</h4>
          </div>
          </div>
          <p>Pre-recorded assets allow you to study for your qualification in your own time, wherever you are.</p>
        </div>



      </div>
      


    </div>
  </section>











  <section class="main-TTT-sec">
    <div class="site-container">
      <div class="reviews-sec">
        <div class="reviews-header">
          <h3 class="big-text">Reviews From Our Students</h3>
        </div>
  
        <div class="reviews-main">
  
          <div class="owl-carousel owl-theme reviews-owl">
            <div class="item">
              <div class="reviews-card">
                <img src="$system_assets_base_url/img/quote-icon.svg" class="quote-icon" />
                <p>Absolutely amazing LMS! The interface is clean and intuitive. Learning has never been more enjoyable.</p>
                <div class="rev-prof">
                  <div class="rev-prof-1">
                    <span>e</span>
                  </div>
                  <div class="rev-prof-2">
                    <h4>Emily Carter</h4>
                  </div>
                </div>

                 <h4 class="h4-ratting-star">5.0
                  <span>
                    <img src="$system_assets_base_url/img/rated-star.svg" />
                    <img src="$system_assets_base_url/img/rated-star.svg" />
                    <img src="$system_assets_base_url/img/rated-star.svg" />
                    <img src="$system_assets_base_url/img/rated-star.svg" />
                    <img src="$system_assets_base_url/img/rated-star.svg" />
                  </span>
                  
                </h4>

              </div>
            </div><!--item-->
  
            <div class="item">
              <div class="reviews-card">
                <img src="$system_assets_base_url/img/quote-icon.svg" class="quote-icon" />
                <p>This platform has transformed the way I teach online. Everything just works flawlessly!</p>
                <div class="rev-prof">
                  <div class="rev-prof-1">
                    <span>d</span>
                  </div>
                  <div class="rev-prof-2">
                    <h4>Daniel Kim</h4>
                  </div>
                </div>

                     <h4 class="h4-ratting-star">5.0
                  <span>
                    <img src="$system_assets_base_url/img/rated-star.svg" />
                    <img src="$system_assets_base_url/img/rated-star.svg" />
                    <img src="$system_assets_base_url/img/rated-star.svg" />
                    <img src="$system_assets_base_url/img/rated-star.svg" />
                    <img src="$system_assets_base_url/img/rated-star.svg" />
                  </span>
                  
                </h4>
              </div>
            </div><!--item-->
            
            
            
            
            
             <div class="item">
              <div class="reviews-card">
                <img src="$system_assets_base_url/img/quote-icon.svg" class="quote-icon" />
                <p>Incredible learning experience. The quizzes, videos, and certificates are spot-on. Highly recommend!</p>
                <div class="rev-prof">
                  <div class="rev-prof-1">
                    <span>s</span>
                  </div>
                  <div class="rev-prof-2">
                    <h4>Sofia Rodriguez</h4>
                  </div>
                </div>

                     <h4 class="h4-ratting-star">5.0
                  <span>
                    <img src="$system_assets_base_url/img/rated-star.svg" />
                    <img src="$system_assets_base_url/img/rated-star.svg" />
                    <img src="$system_assets_base_url/img/rated-star.svg" />
                    <img src="$system_assets_base_url/img/rated-star.svg" />
                    <img src="$system_assets_base_url/img/rated-star.svg" />
                  </span>
                  
                </h4>
              </div>
            </div><!--item-->
            
            
            
            
            
            
             <div class="item">
              <div class="reviews-card">
                <img src="$system_assets_base_url/img/quote-icon.svg" class="quote-icon" />
                <p>One of the best e-learning platforms I've ever used. The features are robust and user-friendly.</p>
                <div class="rev-prof">
                  <div class="rev-prof-1">
                    <span>j</span>
                  </div>
                  <div class="rev-prof-2">
                    <h4>James Thompson</h4>
                  </div>
                </div>

                <h4 class="h4-ratting-star">5.0
                  <span>
                    <img src="$system_assets_base_url/img/rated-star.svg" />
                    <img src="$system_assets_base_url/img/rated-star.svg" />
                    <img src="$system_assets_base_url/img/rated-star.svg" />
                    <img src="$system_assets_base_url/img/rated-star.svg" />
                    <img src="$system_assets_base_url/img/rated-star.svg" />
                  </span>
                  
                </h4>
              </div>
            </div><!--item-->
            
            
            
            
  
            
          </div><!--owl-->
  
        </div>
  
        </div>
      </div>
      </section>
  
  
      <section class="geti-sec">
        <div class="main-container">
          <div class="geti-main">
            <div class="geti-Box">
            <h2 class="large-text">Improving lives through learning</h2>
            <a href="$system_base_url/home/book_class">Book a class now</a>
          </div>
          </div>
        </div>
      </section>
HTML;
?>

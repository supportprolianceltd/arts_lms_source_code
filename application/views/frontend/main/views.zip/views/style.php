<style>
  .sub-CC-Card h3 b.HH3-Ammint b{
    font-size: 17px !important;
    font-weight: 700 !important;
    color: #3F8AEF !important;
     padding:0px !important;
    background-color: transparent !important;
}
@media screen and (max-width:400px){
   .sub-CC-Card h3 b.HH3-Ammint span{
        font-size: 15px !important;
    }
}

 .sub-CC-Card h5{
     font-weight:400 !important;
     color:#54616C !important;
     margin-top:10px !important;
 }
   
      .sub-CC-Card h3 b.HH3-Ammint span{
       color:#54616C !important;
       font-size:12px !important;
       font-weight:400 !important;
       text-decoration: line-through !important;
        padding:0px !important;
    background-color: transparent !important;
   }
   
   
   .Top-Gland-card-1 img{
       width:50px !important;
       height:50px !important;
       border-radius:50% !important;
       object-fit:cover !important;
       object-position:center !important;
   }
   
</style>

<?php
$top_courses_sub_category_card_td.=<<<HTML
    <a href="$system_base_url/home/category/$categories_list_name_slug/{$categories_list['id']}" data-image="$categories_list_thumbnail">{$categories_list['name']}</a>
HTML;
?>